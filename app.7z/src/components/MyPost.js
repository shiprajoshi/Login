// import React from 'react';
// const MyPost=(props)=>{
//     console.log(props)
//     return(
//         <tr>
//             {
//                 props.postDetails!==null?
//                 <React.Fragment>
//                 <tr>
//                 <td><input type="checkbox"/></td>
//                 <td><h3>{props.postDetails.title}</h3>
//                 <p>{props.postDetails.body}</p> 
//                 </td>
//                 <td><button onClick={()=>props.delete(props.postDetails.id)}>delete</button></td>
//                 </tr>
//                 </React.Fragment>
//                 :null
//             }
//          </tr>
//     )

// }
//     //


// export default MyPost;