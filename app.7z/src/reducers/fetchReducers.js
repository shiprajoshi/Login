import {FETCH_POSTS, POST_POSTS, DELETE_POST, ADD_FILE} from './../actions/types';
//import {initialState} from './index'
export const initialState={
    items: [],
    item:{},
    fileName:''
}

export default function fetchReducers(state=initialState, action){
    console.log('actions', action)
    switch (action.type) {
        // case FETCH_POSTS:
        //     return{
        //         ...state,
        //         items: action.posts    
        //     };

        // case POST_POSTS:
        // return{
        //     ...state,
        //         item: action.postItem   
        // }
        case ADD_FILE:
            return{
                ...state,
                fileName: action.fileName
            }
        // case DELETE_POST:
        //     return{
        //         ...state,
        //         items: state.items.filter((post)=> post.id!==action.id)
        //     }
        default:
           return state;
    }

}


