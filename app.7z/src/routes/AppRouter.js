// import React from 'react';

// class Posts extends React.Component{
// render(){
//     return(
//         <div>
//             Hello Posts
//         </div>
//     )
// }
// }