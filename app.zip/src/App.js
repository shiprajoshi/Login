import React, { Component } from 'react';
import { Route, Switch, BrowserRouter } from "react-router-dom";
import logo from './logo.svg';
import Posts from './components/Posts';
import PostForm from './components/PostForm';
import './App.css';
import {Provider} from 'react-redux';
import store from './store';
import Test from './components/Test';
import New from './components/New';
class App extends Component {
  render() {
    return (
      <Provider store={store}>
      {/* <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header> */}
        <BrowserRouter>
        <Switch>
          <Route exact path="/"><Test/></Route>
          <Route exact path="/new"><New/></Route>

        </Switch>
        </BrowserRouter>
       
        {/* <PostForm/>
        <Posts name="app"/> */}
      {/* </div> */}
      </Provider>
    );
  }
}

export default App;
