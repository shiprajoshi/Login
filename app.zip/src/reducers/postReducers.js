// import {FETCH_POSTS, POST_POSTS} from './../actions/types';
// import {initialState} from './fetchReducers'  
// export default function postReducer(state=initialState, action){
//     console.log(state, 'postReducers')
//     switch (action.type) {
//         case POST_POSTS:
//             return{
//                 item: action.postItem
//             }
            
    
//         default:
//             return state;
//     }

// }