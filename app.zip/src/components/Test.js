import React, { useState } from 'react';
import {connect} from 'react-redux';
import { addFile } from './../actions/index';
import { withRouter } from 'react-router-dom';
class Test extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        fileName: ''
      };
    }
     handleonChange=(e)=>{
         this.setState({
             fileName : e.target.files[0].name
         })
         this.props.fileName(e.target.files[0].name)
        this.props.history.push('/new')
      //  setFileName(e.target.files[0].name);
       // console.log('evemt!', e.target.files[0].name)
    }
    render() {
      return (
        <div>
        <label>Choose file</label>
        <br/>
       <input type="file"onChange={this.handleonChange}/>
    </div>
      );
    }
  }


// function Test(){

//     const[fileName, setFileName]= useState('');

//     const handleonChange=(e)=>{
//         setFileName(e.target.files[0].name);
//        // console.log('evemt!', e.target.files[0].name)
//     }

//     return(

// <div>
//     <label>Choose file</label>
//     <br/>
//    <input type="file"onChange={handleonChange}/>
// </div>

// );
// }

const mapStateToProps=(state)=>{
console.log('st!!', state);
}

const mapDispatchToProps=(dispatch)=>{
   // console.log('---', fileName)
   console.log('hey dispatch', dispatch)
return{
    fileName: (fn)=>dispatch(addFile(fn))
}
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Test));