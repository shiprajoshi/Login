// export const FETCH_POSTS='FETCH_POSTS';
// export const POST_POSTS='POST_MEMES';
// export const DELETE_POST='DELETE_POST';
export const ADD_FILE = 'ADD_FILE';